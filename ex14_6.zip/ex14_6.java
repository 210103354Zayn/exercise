package com.example.project_2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.io.IOException;

    public class ex14_6 extends Application {
        @Override
        public void start(Stage stage) throws IOException {
            GridPane gridPane = new GridPane();
            gridPane.setHgap(8);
            gridPane.setVgap(8);
            boolean isBlack = false;
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    Rectangle rec = new Rectangle(80, 80, (isBlack) ? Color.BLACK : Color.WHITE);
                    gridPane.add(rec,j,i);
                    isBlack = !isBlack;
                }
                isBlack = !isBlack;
            }

            Scene scene = new Scene(gridPane, 700, 700);
            stage.setScene(scene);
            stage.show();

        }

        public static void main(String[] args) {
            launch();
        }
    }

