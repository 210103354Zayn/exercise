public class ex10_1 {
    public static void main(String args[]){
        Time time = new Time(555550000);
        System.out.println("time = " + time);

        Time time2 = new Time();
        System.out.println("time = " + time2.toString());


    }
}

class Time{
    int hour;
    int minute;
    int second;
    // public Time(int hour, int minute, int second){
    // 	this.hour = hour;
    // 	this.minute = minute;
    // 	this.second = second;
    // }

    public Time(){
        this(System.currentTimeMillis());
    }

    public Time(long elapseTime){
        long seconds = elapseTime / 1000L;
        this.second = (int)(seconds % 60L);
        long minutes = seconds / 60L;
        this.minute = (int)(minutes % 60L);
        int hours = (int)(minutes / 60L);
        this.hour = (hours % 24);
    }

    public String toString() {
        return this.hour + ":" + this.minute + ":" + this.second;
    }



    public int getHour() {
        return this.hour;
    }

    public int getMinute() {
        return this.minute;
    }

    public int getSecond() {
        return this.second;
    }

}
