import java.util.Scanner;

public class ex12_3 {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        int[] arr = getArray();

        System.out.println("Do you want to check array or check the code? \n1 \n2 \n\":\" ");

        int a = scr.nextInt();

        if(a == 1){
            for(int i = 0; i < arr.length; i++){
                System.out.println(arr[i]);
            }
        }
        else{
            System.out.print("Enter the index of the array: ");




            try {

                System.out.println("The corresponding element value is " +
                        arr[scr.nextInt()]);
            }
            catch (ArrayIndexOutOfBoundsException ex) {
                System.out.println("Out of Bounds.");
            }
        }

        // System.out.print("Enter the index of the array: ");




        // try {

        // 	System.out.println("The corresponding element value is " +
        // 		arr[scr.nextInt()]);
        // }
        // catch (ArrayIndexOutOfBoundsException ex) {
        // 	System.out.println("Out of Bounds.");
        // }


    }

    public static int[] getArray(){
        int[] array = new int[100];

        for (int i = 0; i < array.length; i++) {
            array[i] = (int)(Math.random() * 100) + 1;
        }

        return array;
    }
}
