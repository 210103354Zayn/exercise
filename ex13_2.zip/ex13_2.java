import java.util.ArrayList;

public class ex13_2 {
    public static void main(String[] args) {
        ArrayList<Number> list = new ArrayList<Number>();

        //Scanner scr = new Sacnner(System.in);//

        list.add(55);
        list.add(67);
        list.add(12);
        list.add(87);
        list.add(20);
        list.add(31);
        list.add(48);


        // list.add(scr.nextInt());
        // list.add(scr.nextInt());
        // list.add(scr.nextInt());
        // list.add(scr.nextInt());
        // list.add(scr.nextInt());
        // list.add(scr.nextInt());
        // list.add(scr.nextInt());

        // for(int i = 0; i < list.size(); i++){

        // }


        shuffle(list);

        System.out.println(list.toString());


    }

    public static void shuffle(ArrayList<Number> list){
        for(int i = 0; i < list.size() - 1; i++){
            int switchElements = (int)(Math.random() * list.size());
            Number getTemp = list.get(switchElements);
            list.set(switchElements, list.get(i));
            list.set(i, getTemp);
        }
    }
}
