package com.example.javafx;


import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

    public class ex16_1 extends Application {

        public static void main(String[] args) {
            launch(args);
        }

        @Override
        public void start(Stage primaryStage) {

            Text text = new Text("Programming is not fun");
            text.setFont(Font.font("Times New Roman", FontWeight.EXTRA_BOLD, FontPosture.REGULAR, 22));
            text.setFill(Color.WHITE);
            text.setX(0);
            text.setY(100);


            Button toTheRight = new Button("==>");
            Button toTheLeft = new Button("<==");
            toTheLeft.setOnAction(e ->{
                text.setX(text.getX()-10);
            });
            toTheRight.setOnAction(e ->{
                text.setX(text.getX()+10);
            });

            RadioButton red = new RadioButton("Red");
            red.setStyle("-fx-color: red");
            RadioButton yellow = new RadioButton("Yellow");
            yellow.setStyle("-fx-color: yellow");
            RadioButton black = new RadioButton("Black");
            black.setStyle("-fx-color: black");
            RadioButton orange = new RadioButton("Orange");
            orange.setStyle("-fx-color: orange");
            RadioButton green = new RadioButton("Green");
            green.setStyle("-fx-color: green");

            ToggleGroup tg = new ToggleGroup();
            red.setToggleGroup(tg);
            yellow.setToggleGroup(tg);
            black.setToggleGroup(tg);
            orange.setToggleGroup(tg);
            green.setToggleGroup(tg);

            red.setOnAction(e ->{
                text.setFill(Color.RED);
            });
            yellow.setOnAction(e ->{
                text.setFill(Color.YELLOW);
            });
            black.setOnAction(e ->{
                text.setFill(Color.BLACK);
            });
            orange.setOnAction(e ->{
                text.setFill(Color.ORANGE);
            });
            green.setOnAction(e ->{
                text.setFill(Color.GREEN);
            });


            HBox hBox = new HBox(20);
            hBox.getChildren().addAll(red,yellow,black,orange,green);

            StackPane stackPane =new StackPane(hBox);
            hBox.setAlignment(Pos.CENTER);

            HBox hBox1 = new HBox(20);
            hBox1.getChildren().addAll(toTheLeft, toTheRight);

            StackPane stackPane1 =new StackPane(hBox1);
            hBox1.setAlignment(Pos.CENTER);

            BorderPane borderPane = new BorderPane();
            borderPane.getChildren().addAll(text);
            borderPane.setTop(stackPane);
            borderPane.setBottom(stackPane1);
            borderPane.setStyle("-fx-background-color: pink");


            Scene scene = new Scene(borderPane, 400,200);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Exercise16_01");
            primaryStage.show();

        }
    }

