import java.util.Scanner;

public class ex11_2 {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        Person p = new Person("name", "addres", "pnum", "id");
        System.out.println(p.toString());

        Student s = new Student("name", "addres", "pnum", "id");
        System.out.println(s.toString());


        Person person = new Person("name", "addres", "pnum", "id");
        Student student = new Student("name", "addres", "pnum", "id");



        System.out.println(person.toString());
        System.out.println(student.toString());


    }
}


class Person{
    String name;
    String address;
    String phone_number;
    String email_address;


    public Person(String name, String address, String phone_number, String email_address){
        this.name = name;
        this.address = address;
        this.phone_number = phone_number;
        this.email_address = email_address;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phone_number;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phone_number = phone_number;
    }
    public String getEmail() {
        return email_address;
    }

    public void setEmail(String email) {
        this.email_address = email_address;
    }


    public String toString(){
        return "name:" +  getName() + " class:" + getClass().getName();
    }
}

class Student extends Person{
    final String firststatus = "Freshman";
    final String secondstatus = "Sophomore";
    final String thirdstatus = "Junior";
    final String fourthstatus = "Senior";

    public Student(String name, String address, String phone_number, String email_address){
        super(name, address, phone_number, email_address);
    }



    public String toString(){
        return "name:" +  getName() + " class:" + getClass().getName();
    }

}

class Employee extends Person{
    String office;
    double salary;
    MyDate dateHired;


    public Employee(String name, String address, String phone_number, String email_address, String office, double salary) {
        super(name, address, phone_number, email_address);
        this.office = office;
        this.salary = salary;
        this.dateHired = dateHired;



    }


    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getOffice() {
        return office;
    }

    public void setOffice(String office) {
        this.office = office;
    }


    public MyDate getDateHired() {
        return dateHired;
    }

    public void setDateHired(MyDate dateHired) {
        this.dateHired = dateHired;
    }
    @Override
    public String toString(){
        return "name:" +  getName() + " class:" + getClass().getName();
    }





    class MyDate{
        int year;
        int month;
        int day;

        public MyDate(int year, int month, int day){
            this.year = year;
            this.month = month;
            this.day = day;
        }


        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }

        public int getMonth() {
            return month;
        }

        public void setMonth(int month) {
            this.month = month;
        }

        public int getDay() {
            return day;
        }

        public void setDay(int day) {
            this.day = day;
        }


    }
    class Faculty extends Employee{
        double work_hour;
        String rank;

        public Faculty(String name, String address, String phone_number, String email_address, String office, double salary, double work_hour, String rank){
            super(name, address, phone_number, email_address, office, salary);
            this.work_hour = work_hour;
            this.rank = rank;
        }
        @Override
        public String toString() {
            return name + " Faculty";
        }

    }


    class Staff extends Employee{
        String work;

        public Staff(String name, String address, String phone_number, String email_address, String office, double salary, String work){
            super(name, address, phone_number, email_address, office, salary);
            this.work = work;
        }
        @Override
        public String toString() {
            return name + " Staff";
        }
    }
}
