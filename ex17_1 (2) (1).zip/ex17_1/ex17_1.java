import java.util.Scanner;
import java.io.*;

public class ex17_1 {

    public static void main(String[] args) {
        try(
                PrintWriter printWriter = new PrintWriter(new FileOutputStream(new File("Exercise 17_01.txt"), true));
        ){
            for(int i = 0; i < 100; i++){
                printWriter.print((int)(Math.random() * 100) + " ");
            }

        }
        catch (FileNotFoundException fileNotFoundException){
            System.out.println("I can't create a file");
            fileNotFoundException.printStackTrace();

        }

    }
}
